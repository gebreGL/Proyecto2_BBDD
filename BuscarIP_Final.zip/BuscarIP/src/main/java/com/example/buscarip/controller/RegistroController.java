package com.example.buscarip.controller;

import com.example.buscarip.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.*;
import java.util.*;

public class RegistroController implements Initializable{

    @FXML
    private Stage stage;

    @FXML
    private TextField txtUsuario;

    @FXML
    private PasswordField txtContra;

    @FXML
    private PasswordField txtContra2;

    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtApellidos;

    @FXML
    private TextField txtCorreo;


    public void setStage(Stage stage) {
        this.stage = stage;
    }


    public void registro(ActionEvent actionEvent) throws IOException {

        final String user = "root";
        final String url= "jdbc:mysql://localhost:3306/CREDENCIALES";
        final String pass  = "root";

        Connection con = null;
        Statement stm = null;
        ResultSet rs = null;

        try {
            if ((!txtUsuario.getText().isEmpty() && !txtContra.getText().isEmpty()) &&
                    (txtContra.getText().equals(txtContra2.getText())) && !txtNombre.getText().isEmpty()
                    && !txtApellidos.getText().isEmpty() && !txtCorreo.getText().isEmpty()) {

                boolean seguir = true;
                boolean comprobar = false;

                con = DriverManager.getConnection(url, user, pass);
                stm = con.createStatement();
                rs = stm.executeQuery("SELECT * FROM DATOS;");

                while (rs.next() && seguir) {
                    if (txtUsuario.getText().equals(rs.getString(1))) {
                        JOptionPane.showMessageDialog(null, "Ya existe un usuario con ese nombre",
                                "AVISO", JOptionPane.WARNING_MESSAGE);
                        seguir = false;
                        comprobar = true;
                    } else if (txtCorreo.getText().equals(rs.getString(5))) {
                        JOptionPane.showMessageDialog(null, "Ya existe un usuario con ese correo",
                                "AVISO", JOptionPane.WARNING_MESSAGE);
                        seguir = false;
                        comprobar = true;
                    }
                }

                if (!comprobar) {

                    con = DriverManager.getConnection(url, user, pass);
                    stm = con.createStatement();
                    stm.executeUpdate("INSERT INTO DATOS VALUES ('"+ txtUsuario.getText() +"','"+ txtContra.getText()
                            +"','"+ txtNombre.getText() +"','"+ txtApellidos.getText() +"','"+ txtCorreo.getText() +"');");

                    JOptionPane.showMessageDialog(null, "Credenciales válidas",
                            "Validado", JOptionPane.INFORMATION_MESSAGE);
                    Node source = (Node) actionEvent.getSource();
                    Stage stage = (Stage) source.getScene().getWindow();
                    stage.close();
                    Stage st = new Stage();
                    FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("loginview.fxml"));
                    Scene scene3 = new Scene(fxmlLoader.load());
                    st.setScene(scene3);
                    st.show();
                }

            } else {
                JOptionPane.showMessageDialog(null, "Credenciales no válidas",
                        "AVISO", JOptionPane.WARNING_MESSAGE);
            }
        } catch (HeadlessException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public byte[] cifra(String sinCifrar) throws Exception {
        final byte[] bytes = sinCifrar.getBytes(StandardCharsets.UTF_8);
        final Cipher aes = obtieneCipher(true);
        final byte[] cifrado = aes.doFinal(bytes);
        return cifrado;
    }

    private Cipher obtieneCipher(boolean paraCifrar) throws Exception {
        final String frase = "FraseLargaConDiferentesLetrasNumerosYCaracteresEspeciales_áÁéÉíÍóÓúÚüÜñÑ1234567890!#%$&()=%_NO_USAR_ESTA_FRASE!_";
        final MessageDigest digest = MessageDigest.getInstance("SHA");
        digest.update(frase.getBytes(StandardCharsets.UTF_8));
        final SecretKeySpec key = new SecretKeySpec(digest.digest(), 0, 16, "AES");

        final Cipher aes = Cipher.getInstance("AES/ECB/PKCS5Padding");
        if (paraCifrar) {
            aes.init(Cipher.ENCRYPT_MODE, key);
        } else {
            aes.init(Cipher.DECRYPT_MODE, key);
        }

        return aes;
    }


    public void irInicio(ActionEvent actionEvent) throws Throwable {
        Node source = (Node) actionEvent.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
        Stage st = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("loginview.fxml"));
        Scene scene3 = new Scene(fxmlLoader.load());
        st.setScene(scene3);
        st.show();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
