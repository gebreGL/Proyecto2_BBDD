package com.example.buscarip;

public class Launcher {

    public static void main(String[] args) throws Exception {
        Main.main(args);
    }

}
