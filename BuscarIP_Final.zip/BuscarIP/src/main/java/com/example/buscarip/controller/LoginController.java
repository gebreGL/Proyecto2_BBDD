package com.example.buscarip.controller;

import com.example.buscarip.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.*;
import java.util.ResourceBundle;

public class LoginController implements Initializable{

    @FXML
    private Stage stage = new Stage();

    @FXML
    private TextField txtUsuario;

    @FXML
    private PasswordField txtPass;


    public void setStage(Stage stage) {
        this.stage = stage;
    }


    public byte[] cifra(String sinCifrar) throws Exception {
        final byte[] bytes = sinCifrar.getBytes(StandardCharsets.UTF_8);
        final Cipher aes = obtieneCipher(true);
        final byte[] cifrado = aes.doFinal(bytes);
        return cifrado;
    }

    public String descifra(byte[] cifrado) throws Exception {
        final Cipher aes = obtieneCipher(false);
        final byte[] bytes = aes.doFinal(cifrado);
        final String sinCifrar = new String(bytes, "UTF-8");
        return sinCifrar;
    }

    private Cipher obtieneCipher(boolean paraCifrar) throws Exception {
        final String frase = "FraseLargaConDiferentesLetrasNumerosYCaracteresEspeciales_áÁéÉíÍóÓúÚüÜñÑ1234567890!#%$&()=%_NO_USAR_ESTA_FRASE!_";
        final MessageDigest digest = MessageDigest.getInstance("SHA");
        digest.update(frase.getBytes(StandardCharsets.UTF_8));
        final SecretKeySpec key = new SecretKeySpec(digest.digest(), 0, 16, "AES");

        final Cipher aes = Cipher.getInstance("AES/ECB/PKCS5Padding");
        if (paraCifrar) {
            aes.init(Cipher.ENCRYPT_MODE, key);
        } else {
            aes.init(Cipher.DECRYPT_MODE, key);
        }

        return aes;
    }

    public void irRegistroVent(ActionEvent actionEvent) throws IOException {
        Node source = (Node) actionEvent.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
        Stage st = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("registroview.fxml"));
        Scene scene3 = new Scene(fxmlLoader.load());
        st.setScene(scene3);
        st.show();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    public void login(ActionEvent evento) throws IOException, SQLException {
        String usuarioCliente = txtUsuario.getText();
        String passCliente = txtPass.getText();

        final String user = "root";
        final String url= "jdbc:mysql://localhost:3306/CREDENCIALES";
        final String pass  = "root";

        Connection con = null;
        Statement stm = null;
        ResultSet rs = null;

        try {
            con = DriverManager.getConnection(url, user, pass);
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM DATOS;");

            if (!usuarioCliente.isEmpty() && !passCliente.isEmpty()) {
                boolean seguir = true;
                boolean comprobar = false;

                while (rs.next() && seguir) {
                    if (rs.getString(1).equals(usuarioCliente) && rs.getString(2).equals(passCliente)) {
                        JOptionPane.showMessageDialog(null, "Validado correctamente",
                                "Validación", JOptionPane.INFORMATION_MESSAGE);
                        Node source = (Node) evento.getSource();
                        Stage stage = (Stage) source.getScene().getWindow();
                        stage.close();
                        Stage st = new Stage();
                        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("mainview.fxml"));
                        Scene scene4 = new Scene(fxmlLoader.load());
                        st.setScene(scene4);
                        st.show();
                        seguir = false;
                        comprobar = true;
                    }
                }
                if (!comprobar) {
                    JOptionPane.showMessageDialog(null, "Credenciales inválidas",
                            "AVISO", JOptionPane.WARNING_MESSAGE);
                }


            } else {
                JOptionPane.showMessageDialog(null, "ERROR: No coinciden dichos campos", "AVISO", JOptionPane.WARNING_MESSAGE);
            }
        } catch (
                Exception e) {
            throw new RuntimeException(e);
        }
    }
}
